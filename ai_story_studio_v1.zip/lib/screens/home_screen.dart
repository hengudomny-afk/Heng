import 'package:flutter/material.dart';
import 'new_project_screen.dart';
import 'studio_screen.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('🎬 AI Story Studio',
            style: TextStyle(fontWeight: FontWeight.bold)),
        centerTitle: true,
      ),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          const Text('បង្កើតរឿងរបស់អ្នកជាមួយ AI',
              style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          const Text('ពីគំនិតរឿង ទៅជា Script, Scenes និង Video'),
          const SizedBox(height: 24),
          FilledButton.icon(
            onPressed: () {
              Navigator.push(context, MaterialPageRoute(
                builder: (_) => const NewProjectScreen(),
              ));
            },
            icon: const Icon(Icons.auto_awesome),
            label: const Padding(
              padding: EdgeInsets.all(14),
              child: Text('បង្កើតរឿងថ្មី', style: TextStyle(fontSize: 17)),
            ),
          ),
          const SizedBox(height: 28),
          const Text('គម្រោងរបស់ខ្ញុំ',
              style: TextStyle(fontSize: 19, fontWeight: FontWeight.bold)),
          const SizedBox(height: 12),
          _projectCard(context, 'រឿងស្នេហាខ្មែរ ❤️', '8 Scenes • 2:35 min'),
          _projectCard(context, 'ដំណើរទៅឋានព្រះចន្ទ 🌙', '12 Scenes • 4:10 min'),
        ],
      ),
    );
  }

  Widget _projectCard(BuildContext context, String title, String info) {
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: ListTile(
        leading: const CircleAvatar(child: Icon(Icons.movie)),
        title: Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
        subtitle: Text(info),
        trailing: const Icon(Icons.chevron_right),
        onTap: () {
          Navigator.push(context, MaterialPageRoute(
            builder: (_) => StudioScreen(projectTitle: title),
          ));
        },
      ),
    );
  }
}
