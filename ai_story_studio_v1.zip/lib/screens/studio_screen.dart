import 'package:flutter/material.dart';

class StudioScreen extends StatelessWidget {
  final String projectTitle;
  const StudioScreen({super.key, required this.projectTitle});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('🎬 Project Studio')),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          Text(projectTitle,
              style: const TextStyle(fontSize: 23, fontWeight: FontWeight.bold)),
          const SizedBox(height: 6),
          const Text('AI Story Project'),
          const SizedBox(height: 24),
          _tile(context, Icons.description, 'Script', 'សរសេរ និងកែសម្រួលរឿង'),
          _tile(context, Icons.people, 'Characters', 'បង្កើត និងគ្រប់គ្រងតួអង្គ'),
          _tile(context, Icons.movie_creation, 'Scenes', 'បែងចែករឿងជាឈុត'),
          _tile(context, Icons.image, 'Images', 'បង្កើតរូបភាពតាម Scene'),
          _tile(context, Icons.video_library, 'Videos', 'បង្កើត Video តាម Scene'),
          _tile(context, Icons.record_voice_over, 'Voice', 'បង្កើតសំឡេងតួអង្គ'),
          _tile(context, Icons.music_note, 'Music', 'បន្ថែមតន្ត្រី'),
          const SizedBox(height: 18),
          FilledButton.icon(
            onPressed: () => _comingSoon(context),
            icon: const Icon(Icons.auto_awesome),
            label: const Padding(
              padding: EdgeInsets.all(14),
              child: Text('Generate with AI'),
            ),
          ),
          const SizedBox(height: 10),
          OutlinedButton.icon(
            onPressed: () => _comingSoon(context),
            icon: const Icon(Icons.download),
            label: const Text('Export Video'),
          ),
        ],
      ),
    );
  }

  Widget _tile(BuildContext context, IconData icon, String title, String sub) {
    return Card(
      child: ListTile(
        leading: CircleAvatar(child: Icon(icon)),
        title: Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
        subtitle: Text(sub),
        trailing: const Icon(Icons.chevron_right),
        onTap: () => _comingSoon(context),
      ),
    );
  }

  void _comingSoon(BuildContext context) {
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('មុខងារ AI នឹងភ្ជាប់នៅជំហានបន្ទាប់ ✨')),
    );
  }
}
