import 'package:flutter/material.dart';
import 'studio_screen.dart';

class NewProjectScreen extends StatefulWidget {
  const NewProjectScreen({super.key});

  @override
  State<NewProjectScreen> createState() => _NewProjectScreenState();
}

class _NewProjectScreenState extends State<NewProjectScreen> {
  final ideaController = TextEditingController();
  String genre = 'ស្នេហា';
  String language = 'ខ្មែរ';
  String length = 'Short';

  @override
  void dispose() {
    ideaController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('✨ បង្កើតរឿងថ្មី')),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          const Text('គំនិតរឿង',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          TextField(
            controller: ideaController,
            maxLines: 6,
            decoration: const InputDecoration(
              hintText: 'ឧ. បុរសក្រីក្រម្នាក់ស្រឡាញ់នារីអ្នកមាន...',
              border: OutlineInputBorder(),
            ),
          ),
          const SizedBox(height: 18),
          DropdownButtonFormField<String>(
            value: genre,
            decoration: const InputDecoration(
              labelText: 'ប្រភេទរឿង',
              border: OutlineInputBorder(),
            ),
            items: ['ស្នេហា', 'កំប្លែង', 'ភ័យរន្ធត់', 'Fantasy', 'ប្រវត្តិសាស្ត្រ']
                .map((x) => DropdownMenuItem(value: x, child: Text(x)))
                .toList(),
            onChanged: (v) => setState(() => genre = v!),
          ),
          const SizedBox(height: 14),
          DropdownButtonFormField<String>(
            value: language,
            decoration: const InputDecoration(
              labelText: 'ភាសា',
              border: OutlineInputBorder(),
            ),
            items: ['ខ្មែរ', 'English']
                .map((x) => DropdownMenuItem(value: x, child: Text(x)))
                .toList(),
            onChanged: (v) => setState(() => language = v!),
          ),
          const SizedBox(height: 14),
          DropdownButtonFormField<String>(
            value: length,
            decoration: const InputDecoration(
              labelText: 'ប្រវែង',
              border: OutlineInputBorder(),
            ),
            items: ['Short', '5 នាទី', '10 នាទី', '30 នាទី']
                .map((x) => DropdownMenuItem(value: x, child: Text(x)))
                .toList(),
            onChanged: (v) => setState(() => length = v!),
          ),
          const SizedBox(height: 24),
          FilledButton.icon(
            onPressed: () {
              final title = ideaController.text.trim().isEmpty
                  ? 'គម្រោងថ្មី'
                  : ideaController.text.trim();
              Navigator.pushReplacement(context, MaterialPageRoute(
                builder: (_) => StudioScreen(projectTitle: title),
              ));
            },
            icon: const Icon(Icons.auto_awesome),
            label: const Padding(
              padding: EdgeInsets.all(14),
              child: Text('Generate Story', style: TextStyle(fontSize: 17)),
            ),
          ),
        ],
      ),
    );
  }
}
