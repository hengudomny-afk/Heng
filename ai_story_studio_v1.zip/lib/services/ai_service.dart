class AIService {
  // TODO: Connect to your secure backend API.
  // API keys should NOT be stored directly inside the Android app.

  Future<String> generateStory(String idea) async {
    await Future.delayed(const Duration(seconds: 1));
    return 'AI generated story placeholder for: $idea';
  }
}
