import 'package:flutter/material.dart';
import 'screens/home_screen.dart';

void main() {
  runApp(const AIStoryStudioApp());
}

class AIStoryStudioApp extends StatelessWidget {
  const AIStoryStudioApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'AI Story Studio',
      theme: ThemeData(
        useMaterial3: true,
        colorSchemeSeed: Colors.deepPurple,
        scaffoldBackgroundColor: const Color(0xFFF7F5FA),
      ),
      home: const HomeScreen(),
    );
  }
}
