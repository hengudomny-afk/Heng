class Character {
  final String id;
  final String name;
  final String description;

  Character({required this.id, required this.name, required this.description});
}
