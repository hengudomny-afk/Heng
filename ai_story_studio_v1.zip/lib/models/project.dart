class Project {
  final String id;
  final String title;
  final String genre;

  Project({required this.id, required this.title, required this.genre});
}
