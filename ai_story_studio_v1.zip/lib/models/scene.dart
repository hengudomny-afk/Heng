class Scene {
  final String id;
  final int number;
  final String description;

  Scene({required this.id, required this.number, required this.description});
}
