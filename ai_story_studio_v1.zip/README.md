# AI Story Studio

Flutter Android starter project for an AI story/video creation app.

## Run
1. Install Flutter and Android Studio.
2. Open this project.
3. Run `flutter pub get`.
4. Run `flutter run`.

## Build APK
`flutter build apk --release`

The APK will be generated under:
`build/app/outputs/flutter-apk/app-release.apk`

## Next
Connect a secure backend for Story, Image, Video, Voice and Music AI APIs.
Do not put provider API keys directly in the Android app.
